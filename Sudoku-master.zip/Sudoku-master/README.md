#Sudoku Android

### Idea
To make a Sudoku Game App in Android. Documented, Easy to understand code.

### ScreenShot
![Demo Screenshot](http://i.imgur.com/vVxdRGx.png)

### Status
Finished, can be improved though.
